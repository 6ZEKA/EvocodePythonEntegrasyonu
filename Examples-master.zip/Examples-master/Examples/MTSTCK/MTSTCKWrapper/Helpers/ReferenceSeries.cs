﻿
namespace MTSTCKWrapper.Helpers
{
    public class ReferenceSeries
    {
        public ReferenceSeries(string name)
        {
            Name = name;
        }
        public string Name;
        public double Value;
    }
}
